#include <iostream>
using namespace std;

//Function for entering receipient number 
void enterNumber(){
	int mobileNumber;
	int confirmNumber;
	cout << "Enter Mobile number"<<endl;
	cin >> mobileNumber;
	cout << "Confirm mobile number"<<endl;
	cin >> confirmNumber;
	
	if(mobileNumber == confirmNumber){
		int confirmInput;
		string refNumber;
		float amount;
		cout << "Enter reference\n";
		cin >> refNumber;
		cout << "Enter amount\n";
		cin >> amount;
		cout << "Send GHS" <<amount <<" to" <<mobileNumber <<"?" <<endl;
		cout << "Total Fee GHS" <<((1.75/100) * amount) + amount <<" Transanction fee GHS" <<amount <<" + E-Levey "<<(1.75/100) * amount <<endl;
		cout << "Ref: " <<refNumber <<endl;
		cout << "1. Confirm\n";
		cout << "2. Cancel\n";
		cin >> confirmInput;
		if(confirmInput == 1){
			cout<<"GHS"<<amount <<" sent to " <<mobileNumber<<endl;
			std::terminate();
		}
		else if(confirmInput == 2){
			std::terminate();
		}
	} else{
		cout <<"The numbers you entered are not matching. Go back and try again"<<endl;
		std::terminate();
	}
}
//Transfer money function
void transferMoney(){
    cout << "Transfer Money\n";
    cout << "1. Vodafone Network\n";
    cout << "2. Other Network\n";
    cout << "3. To Bank Account\n";
    cout << "4. E-zwich\n";
    cout << "5. From link Bank Account\n";
    cout << "6. To Unregistered\n";
    cout << "0. Go back\n";
    
    int option;
    cin >> option;
    
    if(option == 1){
        // Send money code here
        enterNumber();
    }
    else if(option == 2){
        // Receive money code here
        transferMoney();
    }
    else if(option == 3){
        // Check balance code here
        transferMoney();
    }
    else if(option == 0){
        return;
    }
    else{
        cout << "Invalid option. Please try again.\n";
        transferMoney();
    }
}



void myWallet(){
    cout << "My Wallet Options:\n";
    cout << "1. Check Balance\n";
    cout << "2. Add Money\n";
    cout << "3. Withdraw Money\n";
    cout << "0. Go back\n";
    
    int option;
    cin >> option;
    
    if(option == 1){
        // Check balance code here
        myWallet();
    }
    else if(option == 2){
        // Add money code here
        myWallet();
    }
    else if(option == 3){
        // Withdraw money code here
        myWallet();
    }
    else if(option == 0){
        return;
    }
    else{
        cout << "Invalid option. Please try again.\n";
        myWallet();
    }
}

//Main function goes here
int main(){
    	cout<<"Register your account now\n";
    cout<<"Dial *558# and Continue\n";
	string insert;
     cin >> insert;
     
     if(insert == "*558#"){
        string  name1,name2,name3;
        	cout<<"Name\n";
        cin>>name1;
        cin>>name2;
        cin>>name3;
        string IDType="Ghana card";
	cout<<"ID Type: " <<IDType <<endl;
	string IDNumber;
	cout<<"ID Number\n";
	cin>>IDNumber;
	int pin;
	cout<<"Enter PIN\n";
	cin>>pin;  
	cout<<"\n";
	cout<<"Name: " + name1 + " " + name2 +" "+ name3 <<endl; 
	cout<<"ID Number: " + IDNumber <<endl;
	cout<<"PIN: " << pin <<endl;
	cout<<"Your Vodafone cash has been registered  Dial *110# to continue"<<endl;
}
                       
    
    string input;
    cin >> input;
    
    if(input == "*110#"){
        int option = -1;
        while(option != 0){
            cout << "Menu\n";
            cout << "1. Send Money\n";
            cout << "2. Redraw Cash\n";
            cout << "3. Buy Airtime or Data\n";
            cout << "4. Make Payment\n";
            cout << "5. Financial Services\n";
            cout << "6. My Wallet\n";
            cout << "0. Exit\n";
            
            cin >> option;
            
            if(option == 1){
                transferMoney();
                
            }
            else if(option == 6){
                myWallet();
            }
            else if(option == 0){
                cout << "Thank you for using Vodafone Cash Money System!\n";
            }
                    }
    }
    else{
        cout << "Invalid input. Please try again.\n";
    }
    return 0;
}


    


